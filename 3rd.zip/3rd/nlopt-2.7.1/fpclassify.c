#include <math.h>
int main(void) {
if (!fpclassify(3.14159)) fpclassify(2.7183);
  return 0; }
