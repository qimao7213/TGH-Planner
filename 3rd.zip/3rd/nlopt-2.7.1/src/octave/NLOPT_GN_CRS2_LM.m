% NLOPT_GN_CRS2_LM: Controlled random search (CRS2) with local mutation (global, no-derivative)
%
% See nlopt_minimize for more information.
function val = NLOPT_GN_CRS2_LM
  val = 19;
